CREATE PROCEDURE printRegionsCharacters
    @RegionName NVARCHAR(100)
AS
BEGIN
    DECLARE @FirstName NVARCHAR(50),
            @LastName NVARCHAR(100),
            @Sex CHAR(1)

    DECLARE characterCursor CURSOR FOR
    SELECT character.FirstName, character.LastName, character.Sex
    FROM Character character
    JOIN Region region ON character.Region_ID = region.ID
    WHERE region.Name = @RegionName

    OPEN characterCursor

    FETCH NEXT FROM characterCursor INTO @FirstName, @LastName, @Sex

    WHILE @@FETCH_STATUS = 0
    BEGIN
        PRINT CASE
                  WHEN @Sex = 'F' THEN 'Kobieta '
                  WHEN @Sex = 'M' THEN 'Mezczyzna '
                  ELSE 'Brak informacji'
                  END + @FirstName + ' ' + ISNULL(@LastName, ' ')

        FETCH NEXT FROM characterCursor INTO @FirstName, @LastName, @Sex
    END

    CLOSE characterCursor
    DEALLOCATE characterCursor
END
go

