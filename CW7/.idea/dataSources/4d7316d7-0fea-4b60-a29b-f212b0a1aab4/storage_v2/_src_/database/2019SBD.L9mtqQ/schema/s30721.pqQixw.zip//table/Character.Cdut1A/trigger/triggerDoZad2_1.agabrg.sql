CREATE TRIGGER triggerDoZad2_1
ON Character
INSTEAD OF INSERT
AS
BEGIN
    IF EXISTS (
        SELECT 1
        FROM INSERTED i
        JOIN Region r ON i.Region_ID = r.ID
        WHERE r.Name = 'ZAUN'
    )
    BEGIN
        THROW 50000, 'NIE MOZNA WSTAIAC POSTACI Z REGIONU "ZAUN"', 15
    END;
END;
go

