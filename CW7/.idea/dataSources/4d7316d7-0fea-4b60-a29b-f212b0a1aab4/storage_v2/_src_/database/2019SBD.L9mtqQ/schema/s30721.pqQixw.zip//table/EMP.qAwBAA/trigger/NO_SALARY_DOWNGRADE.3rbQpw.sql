CREATE trigger NO_SALARY_DOWNGRADE
    ON EMP
    after update as
    begin
        if exists(select 1 from inserted i join deleted d on i.EMPNO = d.EMPNO WHERE i.SAL != d.sal)
        throw 50000, 'Nie mozna zmieniac pensji', 15;
    end
go

